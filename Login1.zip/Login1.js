import React, { useState } from 'react';
import './Login1.css'; // Import the CSS file

function Login1() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  

  return (
    <div className="container">
      <form className="form">
        <h2>Login</h2>

        <div className="inputGroup">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input"
            required
          />
          <label className={`floating-label ${email ? 'active' : ''}`}>Email</label>
        </div>

        <div className="inputGroup">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input"
            required
          />
          <label className={`floating-label ${password ? 'active' : ''}`}>Password</label>
        </div>

        <button type="submit" className="button">Login</button>
      </form>
    </div>
  );
}

export default Login1;
